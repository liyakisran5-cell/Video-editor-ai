import React, { useState, useEffect } from 'react';
import {
  Sparkles,
  Volume2,
  Play,
  Pause,
  Wand2,
  RefreshCw,
  Plus,
  Download,
  Layers,
  Sliders,
  Radio,
  Clock,
  Check,
  Film,
  Zap,
  Music,
  ArrowRight,
  Disc,
  Filter,
  Flame,
  Maximize2
} from 'lucide-react';
import { useVideo } from '../context/VideoContext';
import { MireloAudioService, AMBIENT_PRESETS, QUICK_SFX_PRESETS } from '../services/mireloAudioService';
import { SoundSynth } from '../services/soundSynthService';
import { MireloGenerationItem, MireloWorkflow, SFXCategory, SFXVariation } from '../types/mirelo';

export const SoundStudioView: React.FC = () => {
  const { currentProject, currentTime, setCurrentTime, isPlaying, setIsPlaying, setCurrentView } = useVideo();

  const [activeWorkflow, setActiveWorkflow] = useState<MireloWorkflow>('text-to-sfx');
  const [sfxPrompt, setSfxPrompt] = useState('Deep cinematic braam sub bass drop');
  const [selectedCategory, setSelectedCategory] = useState<SFXCategory>('cinematic');
  const [targetDuration, setTargetDuration] = useState<number>(2.0);
  const [isGenerating, setIsGenerating] = useState<boolean>(false);

  // Active Generations History
  const [generatedItems, setGeneratedItems] = useState<MireloGenerationItem[]>([]);
  const [activeItem, setActiveItem] = useState<MireloGenerationItem | null>(null);

  // Active audio audition state
  const [playingVarId, setPlayingVarId] = useState<string | null>(null);
  const [pitchModifier, setPitchModifier] = useState<number>(1.0);
  const [appliedToast, setAppliedToast] = useState<string | null>(null);

  // Ambiencer state
  const [activeAmbientId, setActiveAmbientId] = useState<string | null>(null);
  const [ambientVolume, setAmbientVolume] = useState<number>(65);

  // Extender state
  const [extendingTrack, setExtendingTrack] = useState<string>('Cinematic Background Drone');
  const [extendTargetSec, setExtendTargetSec] = useState<number>(currentProject.duration || 18);
  const [extendResult, setExtendResult] = useState<string | null>(null);

  // Inpainter state
  const [isScanningAudio, setIsScanningAudio] = useState<boolean>(false);
  const [inpaintStatus, setInpaintStatus] = useState<string | null>(null);

  // Initialize with sample generations on mount
  useEffect(() => {
    MireloAudioService.generateTextToSFX(sfxPrompt, selectedCategory, targetDuration).then(item => {
      setGeneratedItems([item]);
      setActiveItem(item);
    });
  }, []);

  const handleGenerateSFX = async () => {
    if (!sfxPrompt.trim()) return;
    setIsGenerating(true);
    try {
      const newItem = await MireloAudioService.generateTextToSFX(sfxPrompt, selectedCategory, targetDuration);
      setGeneratedItems(prev => [newItem, ...prev]);
      setActiveItem(newItem);
    } finally {
      setIsGenerating(false);
    }
  };

  const handleMagicSoundDesign = async () => {
    setIsGenerating(true);
    try {
      const magicItems = await MireloAudioService.generateVideoToSFX(
        currentProject.duration || 18,
        currentProject.analysisReport.detectedTopic
      );
      setGeneratedItems(prev => [...magicItems, ...prev]);
      if (magicItems.length > 0) {
        setActiveItem(magicItems[0]);
      }
      setAppliedToast(`Magic Mode: Generated 4 synchronized Foley & SFX cues across ${currentProject.duration}s video!`);
      setTimeout(() => setAppliedToast(null), 4000);
    } finally {
      setIsGenerating(false);
    }
  };

  const handleAuditionVariation = (variation: SFXVariation) => {
    if (playingVarId === variation.id) {
      setPlayingVarId(null);
      return;
    }
    setPlayingVarId(variation.id);
    SoundSynth.playSound(variation.synthType, variation.duration, 0.85, pitchModifier * variation.pitchModifier);
    setTimeout(() => {
      setPlayingVarId(null);
    }, variation.duration * 1000);
  };

  const handleAddToTimeline = (variation: SFXVariation) => {
    setAppliedToast(`Added "${variation.name}" to Timeline at 00:${currentTime < 10 ? '0' : ''}${currentTime.toFixed(1)}s`);
    setTimeout(() => setAppliedToast(null), 3500);
  };

  const handleDownloadWav = (variation: SFXVariation) => {
    const url = SoundSynth.generateAudioDataUrl(variation.synthType, variation.duration);
    const a = document.createElement('a');
    a.href = url;
    a.download = `${variation.name.toLowerCase().replace(/[^a-z0-9]/g, '_')}.wav`;
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
    setAppliedToast(`Downloaded ${variation.label} (WAV Studio Quality)`);
    setTimeout(() => setAppliedToast(null), 3000);
  };

  const handleExtend = async () => {
    setIsGenerating(true);
    const res = await MireloAudioService.extendAudioTrack(extendingTrack, 6.0, extendTargetSec);
    setIsGenerating(false);
    setExtendResult(res.message);
  };

  const handleInpaint = async () => {
    setIsScanningAudio(true);
    await new Promise(r => setTimeout(r, 1200));
    setIsScanningAudio(false);
    setInpaintStatus('Repaired 3 acoustic artifacts: 1 mouth-smack removed, -18dB room hiss cleaned, 1 glitch crossfaded.');
  };

  return (
    <div className="flex flex-1 flex-col bg-[#050608] text-slate-100 p-3 md:p-4 gap-4 min-h-[calc(100vh-60px)]">
      {/* Toast Notification */}
      {appliedToast && (
        <div className="fixed top-16 right-6 z-50 flex items-center gap-2 rounded-xl bg-emerald-500 px-4 py-2.5 text-xs font-bold text-white shadow-2xl animate-fade-in">
          <Check className="h-4 w-4" />
          <span>{appliedToast}</span>
        </div>
      )}

      {/* 1. Header Banner inspired by Mirelo AI Studio */}
      <div className="flex flex-col md:flex-row items-start md:items-center justify-between gap-3 rounded-2xl border border-indigo-500/30 bg-gradient-to-r from-indigo-950/40 via-purple-950/20 to-slate-900/60 p-4 shadow-xl">
        <div className="flex items-center gap-3">
          <div className="flex h-11 w-11 items-center justify-center rounded-xl bg-indigo-600/20 border border-indigo-500/40 text-indigo-400">
            <Radio className="h-6 w-6 animate-pulse" />
          </div>
          <div>
            <div className="flex items-center gap-2">
              <h1 className="font-['Outfit'] text-lg font-bold text-white">
                Mirelo AI Sound Studio
              </h1>
              <span className="rounded-full border border-indigo-500/40 bg-indigo-500/10 px-2.5 py-0.5 text-[10px] font-bold text-indigo-300">
                Audio 2.0 Engine
              </span>
            </div>
            <p className="text-xs text-slate-400">
              AI-powered Hollywood sound design for video: Video-to-SFX, Text-to-Audio, Loop Ambiencer, and Inpainting.
            </p>
          </div>
        </div>

        {/* Global Action Buttons */}
        <div className="flex items-center gap-2 w-full md:w-auto">
          <button
            id="magic-sound-btn"
            onClick={handleMagicSoundDesign}
            disabled={isGenerating}
            className="flex items-center justify-center gap-2 rounded-xl bg-gradient-to-r from-indigo-500 to-purple-600 px-4 py-2 text-xs font-bold text-white shadow-lg shadow-indigo-500/25 hover:brightness-110 active:scale-95 transition-all"
          >
            <Wand2 className="h-4 w-4" />
            <span>Magic Auto-SFX (Video Sync)</span>
          </button>

          <button
            onClick={() => setCurrentView('editor')}
            className="flex items-center justify-center gap-1.5 rounded-xl border border-slate-700 bg-slate-800/80 px-3.5 py-2 text-xs font-semibold text-slate-300 hover:bg-slate-700 hover:text-white transition-all"
          >
            <Film className="h-4 w-4 text-indigo-400" />
            <span>Return to Video Editor</span>
          </button>
        </div>
      </div>

      {/* 2. Main Workspace Layout */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-4 flex-1">
        {/* Left Column: Tool Mode & Generator (5 Cols) */}
        <div className="lg:col-span-5 flex flex-col rounded-2xl border border-slate-800 bg-[#090b10] shadow-xl overflow-hidden">
          {/* Mode Switcher Tabs */}
          <div className="flex items-center border-b border-slate-800 bg-[#0c0e14] p-1.5 gap-1 overflow-x-auto scrollbar-none">
            {[
              { id: 'text-to-sfx', label: 'Text-to-SFX', icon: Volume2 },
              { id: 'video-to-sfx', label: 'Video-to-SFX', icon: Wand2 },
              { id: 'ambiencer', label: 'Ambiencer', icon: Disc },
              { id: 'extender', label: 'Extender', icon: Clock },
              { id: 'inpainter', label: 'Inpainter', icon: Filter }
            ].map(tab => {
              const Icon = tab.icon;
              const active = activeWorkflow === tab.id;
              return (
                <button
                  key={tab.id}
                  onClick={() => setActiveWorkflow(tab.id as MireloWorkflow)}
                  className={`flex items-center gap-1.5 rounded-lg px-2.5 py-1.5 text-xs font-medium whitespace-nowrap transition-all ${
                    active
                      ? 'bg-indigo-600 text-white shadow-md'
                      : 'text-slate-400 hover:bg-slate-800 hover:text-slate-200'
                  }`}
                >
                  <Icon className="h-3.5 w-3.5" />
                  <span>{tab.label}</span>
                </button>
              );
            })}
          </div>

          <div className="flex-1 p-4 space-y-4 overflow-y-auto text-xs">
            {/* WORKFLOW 1: TEXT-TO-SFX */}
            {activeWorkflow === 'text-to-sfx' && (
              <div className="space-y-4">
                <div>
                  <label className="text-[11px] font-bold uppercase tracking-wider text-slate-400">
                    Sound Prompt & Description
                  </label>
                  <div className="mt-1.5 relative">
                    <textarea
                      value={sfxPrompt}
                      onChange={e => setSfxPrompt(e.target.value)}
                      placeholder="e.g. Deep cinematic braam sub bass drop, laser blaster burst, heavy door thud..."
                      rows={3}
                      className="w-full rounded-xl border border-slate-700 bg-slate-900/90 p-3 text-xs text-slate-100 placeholder-slate-500 focus:border-indigo-500 focus:outline-none"
                    />
                  </div>
                </div>

                {/* Quick Presets */}
                <div>
                  <span className="text-[11px] font-bold uppercase tracking-wider text-slate-400">
                    Quick Sound Presets
                  </span>
                  <div className="mt-1.5 flex flex-wrap gap-1.5">
                    {QUICK_SFX_PRESETS.map((p, idx) => (
                      <button
                        key={idx}
                        onClick={() => {
                          setSfxPrompt(p.prompt);
                          setSelectedCategory(p.category);
                        }}
                        className="rounded-lg border border-slate-800 bg-slate-900/80 px-2.5 py-1 text-[11px] text-slate-300 hover:border-indigo-500 hover:text-indigo-300 transition-all"
                      >
                        {p.prompt}
                      </button>
                    ))}
                  </div>
                </div>

                {/* Category & Duration Controls */}
                <div className="grid grid-cols-2 gap-3">
                  <div>
                    <label className="text-[11px] font-bold text-slate-400">Category</label>
                    <select
                      value={selectedCategory}
                      onChange={e => setSelectedCategory(e.target.value as SFXCategory)}
                      className="mt-1 w-full rounded-lg border border-slate-700 bg-slate-900 p-2 text-xs text-slate-200"
                    >
                      <option value="cinematic">Cinematic</option>
                      <option value="impact">Impact / Hit</option>
                      <option value="whoosh">Whoosh / Swish</option>
                      <option value="ui">UI & Haptic</option>
                      <option value="foley">Foley / Action</option>
                      <option value="scifi">Sci-Fi & Cyber</option>
                      <option value="nature">Nature & Ambient</option>
                    </select>
                  </div>

                  <div>
                    <label className="text-[11px] font-bold text-slate-400">
                      Duration: {targetDuration.toFixed(1)}s
                    </label>
                    <input
                      type="range"
                      min={0.5}
                      max={8.0}
                      step={0.5}
                      value={targetDuration}
                      onChange={e => setTargetDuration(parseFloat(e.target.value))}
                      className="mt-2 w-full accent-indigo-500 cursor-pointer"
                    />
                  </div>
                </div>

                {/* Generate Button */}
                <button
                  id="generate-sfx-btn"
                  onClick={handleGenerateSFX}
                  disabled={isGenerating}
                  className="flex w-full items-center justify-center gap-2 rounded-xl bg-indigo-600 hover:bg-indigo-500 py-3 text-xs font-bold text-white shadow-lg shadow-indigo-600/30 transition-all active:scale-98"
                >
                  {isGenerating ? (
                    <>
                      <RefreshCw className="h-4 w-4 animate-spin" />
                      <span>Synthesizing 4 Audio Variations...</span>
                    </>
                  ) : (
                    <>
                      <Sparkles className="h-4 w-4" />
                      <span>Generate 4 SFX Candidates</span>
                    </>
                  )}
                </button>
              </div>
            )}

            {/* WORKFLOW 2: VIDEO-TO-SFX (MAGIC MODE) */}
            {activeWorkflow === 'video-to-sfx' && (
              <div className="space-y-4">
                <div className="rounded-xl border border-indigo-500/30 bg-indigo-950/20 p-3.5 space-y-2">
                  <div className="flex items-center gap-2">
                    <Sparkles className="h-4 w-4 text-indigo-400" />
                    <span className="font-bold text-indigo-300">AI Scene Audio Compositor</span>
                  </div>
                  <p className="text-slate-300 leading-relaxed">
                    Mirelo AI scans your raw video footage, captions, and cuts to detect visual cues (zooms, text pops, transitions, high-energy speech) and automatically places Hollywood sound effects with millisecond precision.
                  </p>
                </div>

                <div className="rounded-xl border border-slate-800 bg-slate-900/80 p-3 space-y-2">
                  <span className="font-bold text-slate-300">Target Video: {currentProject.name}</span>
                  <div className="flex items-center justify-between text-slate-400 text-[11px]">
                    <span>Length: {currentProject.duration}s</span>
                    <span>Resolution: {currentProject.resolution}</span>
                    <span>Captions: {currentProject.captions.length} events</span>
                  </div>
                </div>

                <button
                  onClick={handleMagicSoundDesign}
                  disabled={isGenerating}
                  className="flex w-full items-center justify-center gap-2 rounded-xl bg-gradient-to-r from-indigo-500 to-purple-600 py-3.5 text-xs font-bold text-white shadow-lg shadow-indigo-500/30 transition-all hover:brightness-110"
                >
                  {isGenerating ? (
                    <>
                      <RefreshCw className="h-4 w-4 animate-spin" />
                      <span>Analyzing Visuals & Foley Cues...</span>
                    </>
                  ) : (
                    <>
                      <Wand2 className="h-4 w-4" />
                      <span>Run 1-Click Video Sound Design</span>
                    </>
                  )}
                </button>
              </div>
            )}

            {/* WORKFLOW 3: AMBIENCER */}
            {activeWorkflow === 'ambiencer' && (
              <div className="space-y-3">
                <span className="text-[11px] font-bold uppercase tracking-wider text-slate-400">
                  Loopable Ambient Soundscapes
                </span>
                <p className="text-slate-400 text-[11px]">
                  Generate seamless background textures and room tones tailored for podcasts, tech demos, and cinematic trailers.
                </p>

                <div className="space-y-2">
                  {AMBIENT_PRESETS.map(amb => {
                    const isPlayingAmb = activeAmbientId === amb.id;
                    return (
                      <div
                        key={amb.id}
                        className={`rounded-xl border p-3 transition-all ${
                          isPlayingAmb
                            ? 'border-indigo-500 bg-indigo-950/40 shadow-md'
                            : 'border-slate-800 bg-slate-900/80 hover:border-slate-700'
                        }`}
                      >
                        <div className="flex items-center justify-between">
                          <div>
                            <p className="font-bold text-slate-200">{amb.name}</p>
                            <p className="text-[11px] text-slate-400 mt-0.5">{amb.description}</p>
                          </div>
                          <button
                            onClick={() => {
                              if (isPlayingAmb) {
                                setActiveAmbientId(null);
                              } else {
                                setActiveAmbientId(amb.id);
                                SoundSynth.playSound(amb.synthType, amb.loopLength, ambientVolume / 100);
                              }
                            }}
                            className={`flex h-8 w-8 items-center justify-center rounded-lg ${
                              isPlayingAmb ? 'bg-indigo-600 text-white' : 'bg-slate-800 text-slate-300 hover:bg-slate-700'
                            }`}
                          >
                            {isPlayingAmb ? <Pause className="h-4 w-4" /> : <Play className="h-4 w-4 fill-current ml-0.5" />}
                          </button>
                        </div>

                        <div className="mt-2.5 flex items-center justify-between border-t border-slate-800/80 pt-2 text-[10px]">
                          <span className="text-slate-400">Seamless Loop: {amb.loopLength}s</span>
                          <button
                            onClick={() => {
                              setAppliedToast(`Applied "${amb.name}" as Timeline Ambient Bed`);
                              setTimeout(() => setAppliedToast(null), 3000);
                            }}
                            className="flex items-center gap-1 font-bold text-indigo-400 hover:text-indigo-300"
                          >
                            <Plus className="h-3 w-3" />
                            <span>Add Bed Track</span>
                          </button>
                        </div>
                      </div>
                    );
                  })}
                </div>
              </div>
            )}

            {/* WORKFLOW 4: EXTENDER */}
            {activeWorkflow === 'extender' && (
              <div className="space-y-4">
                <div className="rounded-xl border border-slate-800 bg-slate-900/80 p-3.5 space-y-3">
                  <span className="font-bold text-slate-200">AI Audio Extender & Loop Seamlessness</span>
                  <p className="text-slate-400 text-[11px]">
                    Lengthen any sound effect, riser, or ambient loop to match your exact video timeline length with AI harmonic crossfading.
                  </p>

                  <div>
                    <label className="text-[11px] font-bold text-slate-400">Track to Extend</label>
                    <input
                      type="text"
                      value={extendingTrack}
                      onChange={e => setExtendingTrack(e.target.value)}
                      className="mt-1 w-full rounded-lg border border-slate-700 bg-slate-900 p-2 text-xs text-slate-200"
                    />
                  </div>

                  <div>
                    <label className="text-[11px] font-bold text-slate-400">
                      Target Length: {extendTargetSec} seconds (Full Video Duration)
                    </label>
                    <input
                      type="range"
                      min={5}
                      max={60}
                      value={extendTargetSec}
                      onChange={e => setExtendTargetSec(parseInt(e.target.value))}
                      className="mt-2 w-full accent-indigo-500"
                    />
                  </div>

                  <button
                    onClick={handleExtend}
                    disabled={isGenerating}
                    className="flex w-full items-center justify-center gap-2 rounded-xl bg-indigo-600 hover:bg-indigo-500 py-2.5 font-bold text-white"
                  >
                    <Clock className="h-4 w-4" />
                    <span>Extend Audio Track</span>
                  </button>

                  {extendResult && (
                    <div className="rounded-lg bg-emerald-950/40 border border-emerald-500/40 p-2.5 text-[11px] text-emerald-300">
                      {extendResult}
                    </div>
                  )}
                </div>
              </div>
            )}

            {/* WORKFLOW 5: INPAINTER */}
            {activeWorkflow === 'inpainter' && (
              <div className="space-y-4">
                <div className="rounded-xl border border-slate-800 bg-slate-900/80 p-3.5 space-y-3">
                  <span className="font-bold text-slate-200">AI Audio Inpainter & Artifact Eraser</span>
                  <p className="text-slate-400 text-[11px]">
                    Mirelo SFX Inpainter repairs clicks, lip smacks, background fan hisses, and room reverberation by regenerating pristine audio segments.
                  </p>

                  <button
                    onClick={handleInpaint}
                    disabled={isScanningAudio}
                    className="flex w-full items-center justify-center gap-2 rounded-xl bg-indigo-600 hover:bg-indigo-500 py-2.5 font-bold text-white"
                  >
                    <Filter className="h-4 w-4" />
                    <span>{isScanningAudio ? 'Scanning Audio Waveform...' : 'Scan & Inpaint Audio Artifacts'}</span>
                  </button>

                  {inpaintStatus && (
                    <div className="rounded-lg bg-emerald-950/40 border border-emerald-500/40 p-2.5 text-[11px] text-emerald-300">
                      {inpaintStatus}
                    </div>
                  )}
                </div>
              </div>
            )}
          </div>
        </div>

        {/* Right Column: Audio Variations & Video Compositor Sync (7 Cols) */}
        <div className="lg:col-span-7 flex flex-col gap-4">
          {/* Active Sound Candidates (Sample A, B, C, D) */}
          <div className="rounded-2xl border border-slate-800 bg-[#090b10] p-4 shadow-xl space-y-3">
            <div className="flex items-center justify-between">
              <div>
                <span className="text-[11px] font-bold uppercase tracking-wider text-slate-400">
                  Generated Candidates
                </span>
                <h3 className="font-['Outfit'] font-bold text-white text-sm">
                  {activeItem ? activeItem.prompt : 'Deep Cinematic Braam Drop'}
                </h3>
              </div>

              {activeItem?.visualCue && (
                <span className="rounded-full bg-indigo-950 border border-indigo-800 px-3 py-1 text-[11px] text-indigo-300 font-mono">
                  Cue: {activeItem.visualCue}
                </span>
              )}
            </div>

            {/* 4 Candidate Variation Cards */}
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
              {activeItem?.variations.map((v, i) => {
                const isPlaying = playingVarId === v.id;
                return (
                  <div
                    key={v.id}
                    className={`rounded-xl border p-3 transition-all ${
                      isPlaying
                        ? 'border-indigo-500 bg-indigo-950/30 shadow-lg'
                        : 'border-slate-800 bg-slate-900/70 hover:border-slate-700'
                    }`}
                  >
                    <div className="flex items-center justify-between">
                      <span className="font-bold text-slate-200 text-xs">{v.label}</span>
                      <span className="font-mono text-[10px] text-slate-400">{v.duration}s</span>
                    </div>

                    <p className="text-[10px] text-slate-400 mt-1 leading-snug">{v.description}</p>

                    {/* Interactive Waveform visualizer */}
                    <div className="my-2.5 flex h-8 items-center gap-0.5 rounded-lg bg-black/40 p-1.5 overflow-hidden">
                      {v.waveform.map((bar, idx) => (
                        <div
                          key={idx}
                          className={`flex-1 rounded-sm transition-all duration-200 ${
                            isPlaying ? 'bg-indigo-400 animate-pulse' : 'bg-slate-600'
                          }`}
                          style={{ height: `${Math.max(15, bar * 100)}%` }}
                        />
                      ))}
                    </div>

                    {/* Action Controls */}
                    <div className="flex items-center gap-1.5 pt-1">
                      <button
                        onClick={() => handleAuditionVariation(v)}
                        className={`flex flex-1 items-center justify-center gap-1.5 rounded-lg py-1.5 text-xs font-bold transition-all ${
                          isPlaying
                            ? 'bg-indigo-500 text-white'
                            : 'bg-slate-800 hover:bg-slate-700 text-slate-200'
                        }`}
                      >
                        {isPlaying ? <Pause className="h-3.5 w-3.5" /> : <Play className="h-3.5 w-3.5 fill-current" />}
                        <span>{isPlaying ? 'Playing' : 'Audition'}</span>
                      </button>

                      <button
                        onClick={() => handleAddToTimeline(v)}
                        title="Add to Timeline at current playhead"
                        className="flex items-center justify-center rounded-lg bg-emerald-950 border border-emerald-800/80 px-2.5 py-1.5 text-emerald-300 hover:bg-emerald-900 transition-all text-xs font-semibold"
                      >
                        <Plus className="h-3.5 w-3.5" />
                      </button>

                      <button
                        onClick={() => handleDownloadWav(v)}
                        title="Download Studio WAV"
                        className="flex items-center justify-center rounded-lg bg-slate-800 px-2.5 py-1.5 text-slate-400 hover:text-white transition-all text-xs"
                      >
                        <Download className="h-3.5 w-3.5" />
                      </button>
                    </div>
                  </div>
                );
              })}
            </div>
          </div>

          {/* Timeline Multi-Track Audio Stem Mixer */}
          <div className="flex-1 rounded-2xl border border-slate-800 bg-[#090b10] p-4 shadow-xl space-y-3">
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-2">
                <Layers className="h-4 w-4 text-indigo-400" />
                <span className="font-['Outfit'] font-bold text-white text-xs">
                  Multi-Track Sound Mixer & Stem Control
                </span>
              </div>
              <span className="text-[10px] text-slate-400 font-mono">Master: -14.2 LUFS</span>
            </div>

            <div className="space-y-2">
              {[
                { name: 'Video Dialogue Track', type: 'Speech', vol: 85, color: '#6366F1' },
                { name: 'SFX Track 1 (Impacts & Drops)', type: 'Foley', vol: 78, color: '#EC4899' },
                { name: 'SFX Track 2 (Whooshes & Cues)', type: 'Transitions', vol: 72, color: '#38BDF8' },
                { name: 'Ambience Bed (Room Tone)', type: 'Atmosphere', vol: 45, color: '#10B981' },
                { name: 'Music Score (Hans Zimmer Synth)', type: 'Music', vol: 55, color: '#F59E0B' }
              ].map((trk, i) => (
                <div
                  key={i}
                  className="flex items-center justify-between rounded-xl border border-slate-800/80 bg-slate-900/60 p-2.5 text-xs"
                >
                  <div className="flex items-center gap-2 w-48">
                    <span className="flex h-2.5 w-2.5 rounded-full" style={{ backgroundColor: trk.color }} />
                    <div>
                      <p className="font-semibold text-slate-200 text-[11px] truncate">{trk.name}</p>
                      <p className="text-[9px] text-slate-400">{trk.type}</p>
                    </div>
                  </div>

                  <div className="flex items-center gap-3 flex-1 px-4">
                    <input
                      type="range"
                      min={0}
                      max={100}
                      defaultValue={trk.vol}
                      className="w-full accent-indigo-500 cursor-pointer"
                    />
                    <span className="font-mono text-[10px] text-slate-400 w-8">{trk.vol}%</span>
                  </div>

                  <div className="flex items-center gap-1">
                    <button className="rounded px-2 py-0.5 text-[10px] font-bold bg-slate-800 text-slate-400 hover:text-white">
                      M
                    </button>
                    <button className="rounded px-2 py-0.5 text-[10px] font-bold bg-slate-800 text-slate-400 hover:text-white">
                      S
                    </button>
                  </div>
                </div>
              ))}
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
