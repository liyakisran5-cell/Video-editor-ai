export type MireloWorkflow =
  | 'video-to-sfx'
  | 'text-to-sfx'
  | 'ambiencer'
  | 'extender'
  | 'inpainter';

export type SFXCategory =
  | 'cinematic'
  | 'foley'
  | 'ui'
  | 'whoosh'
  | 'nature'
  | 'impact'
  | 'scifi'
  | 'magic';

export interface SFXVariation {
  id: string;
  name: string;
  label: string; // e.g. "Sample A", "Sample B"
  duration: number; // in seconds
  synthType: 'whoosh' | 'impact' | 'braam' | 'laser' | 'ui-click' | 'rain' | 'ambience' | 'glitch' | 'footstep' | 'riser';
  pitchModifier: number;
  reverb: number; // 0-100
  waveform: number[]; // 24-40 amplitude bars for UI visualization
  audioUrl?: string;
  description: string;
  tags: string[];
}

export interface MireloGenerationItem {
  id: string;
  prompt: string;
  category: SFXCategory;
  timestamp: string;
  timelineStart?: number; // Video time alignment in seconds
  visualCue?: string; // e.g. "Speaker hits table", "Fast transition cut"
  variations: SFXVariation[];
  selectedVariationId: string;
  mode: 'magic' | 'manual';
  status: 'ready' | 'generating' | 'applied';
}

export interface AmbientPreset {
  id: string;
  name: string;
  description: string;
  category: 'indoor' | 'nature' | 'urban' | 'scifi' | 'studio';
  synthType: 'ambience' | 'rain';
  loopLength: number;
  color: string;
  tags: string[];
}

export interface AudioInpaintRegion {
  id: string;
  start: number;
  end: number;
  issueType: 'noise' | 'click' | 'mouth-smack' | 'reverb-tail' | 'background-chatter';
  action: 'denoise' | 'mute' | 'regenerate' | 'smooth-crossfade';
  status: 'detected' | 'repaired';
}
