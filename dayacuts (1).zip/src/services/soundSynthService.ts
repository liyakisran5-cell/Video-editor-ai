/**
 * Web Audio API Sound Synthesizer Engine
 * Generates realistic audio waveforms (SFX, impacts, whooshes, ambiences, UI sounds)
 * directly in the browser for instant auditioning and exporting.
 */

class SoundSynthEngine {
  private ctx: AudioContext | null = null;

  private getContext(): AudioContext {
    if (!this.ctx) {
      const AudioCtx = window.AudioContext || (window as any).webkitAudioContext;
      this.ctx = new AudioCtx();
    }
    if (this.ctx.state === 'suspended') {
      this.ctx.resume();
    }
    return this.ctx;
  }

  /**
   * Generates sound based on category and style parameters
   */
  public playSound(
    type: 'whoosh' | 'impact' | 'braam' | 'laser' | 'ui-click' | 'rain' | 'ambience' | 'glitch' | 'footstep' | 'riser',
    duration: number = 2.0,
    volume: number = 0.8,
    pitchModifier: number = 1.0
  ): void {
    try {
      const ctx = this.getContext();
      const now = ctx.currentTime;

      switch (type) {
        case 'whoosh': {
          // Filtered noise with pitch sweep
          const bufferSize = ctx.sampleRate * Math.min(duration, 3);
          const noiseBuffer = ctx.createBuffer(1, bufferSize, ctx.sampleRate);
          const output = noiseBuffer.getChannelData(0);
          for (let i = 0; i < bufferSize; i++) {
            output[i] = Math.random() * 2 - 1;
          }
          const whiteNoise = ctx.createBufferSource();
          whiteNoise.buffer = noiseBuffer;

          const filter = ctx.createBiquadFilter();
          filter.type = 'bandpass';
          filter.frequency.setValueAtTime(200 * pitchModifier, now);
          filter.frequency.exponentialRampToValueAtTime(3200 * pitchModifier, now + duration * 0.5);
          filter.frequency.exponentialRampToValueAtTime(150 * pitchModifier, now + duration);
          filter.Q.setValueAtTime(3.5, now);

          const gain = ctx.createGain();
          gain.gain.setValueAtTime(0.001, now);
          gain.gain.exponentialRampToValueAtTime(volume * 0.9, now + duration * 0.45);
          gain.gain.exponentialRampToValueAtTime(0.0001, now + duration);

          whiteNoise.connect(filter);
          filter.connect(gain);
          gain.connect(ctx.destination);

          whiteNoise.start(now);
          whiteNoise.stop(now + duration);
          break;
        }

        case 'impact':
        case 'braam': {
          // Low sub bass drop with distorted overtone
          const osc1 = ctx.createOscillator();
          const osc2 = ctx.createOscillator();
          const gain = ctx.createGain();

          osc1.type = type === 'braam' ? 'sawtooth' : 'sine';
          osc2.type = 'triangle';

          const baseFreq = (type === 'braam' ? 65 : 120) * pitchModifier;
          osc1.frequency.setValueAtTime(baseFreq * 2.2, now);
          osc1.frequency.exponentialRampToValueAtTime(baseFreq * 0.6, now + duration * 0.7);

          osc2.frequency.setValueAtTime(baseFreq * 1.5, now);
          osc2.frequency.exponentialRampToValueAtTime(35, now + duration);

          const filter = ctx.createBiquadFilter();
          filter.type = 'lowpass';
          filter.frequency.setValueAtTime(type === 'braam' ? 900 : 350, now);
          filter.frequency.exponentialRampToValueAtTime(80, now + duration);

          gain.gain.setValueAtTime(volume, now);
          gain.gain.exponentialRampToValueAtTime(0.0001, now + duration);

          osc1.connect(filter);
          osc2.connect(filter);
          filter.connect(gain);
          gain.connect(ctx.destination);

          osc1.start(now);
          osc2.start(now);
          osc1.stop(now + duration);
          osc2.stop(now + duration);
          break;
        }

        case 'riser': {
          // Ascending pitch build up
          const osc = ctx.createOscillator();
          const filter = ctx.createBiquadFilter();
          const gain = ctx.createGain();

          osc.type = 'sawtooth';
          osc.frequency.setValueAtTime(120 * pitchModifier, now);
          osc.frequency.exponentialRampToValueAtTime(1400 * pitchModifier, now + duration);

          filter.type = 'lowpass';
          filter.frequency.setValueAtTime(300, now);
          filter.frequency.exponentialRampToValueAtTime(4500, now + duration);

          gain.gain.setValueAtTime(0.05, now);
          gain.gain.exponentialRampToValueAtTime(volume * 0.9, now + duration * 0.95);
          gain.gain.exponentialRampToValueAtTime(0.0001, now + duration);

          osc.connect(filter);
          filter.connect(gain);
          gain.connect(ctx.destination);

          osc.start(now);
          osc.stop(now + duration);
          break;
        }

        case 'laser':
        case 'glitch': {
          const osc = ctx.createOscillator();
          const gain = ctx.createGain();

          osc.type = type === 'laser' ? 'sawtooth' : 'square';
          osc.frequency.setValueAtTime(1800 * pitchModifier, now);
          osc.frequency.exponentialRampToValueAtTime(120, now + 0.35);

          gain.gain.setValueAtTime(volume * 0.7, now);
          gain.gain.exponentialRampToValueAtTime(0.0001, now + 0.35);

          osc.connect(gain);
          gain.connect(ctx.destination);

          osc.start(now);
          osc.stop(now + 0.35);
          break;
        }

        case 'ui-click': {
          const osc = ctx.createOscillator();
          const gain = ctx.createGain();

          osc.type = 'sine';
          osc.frequency.setValueAtTime(1200 * pitchModifier, now);
          osc.frequency.exponentialRampToValueAtTime(600, now + 0.08);

          gain.gain.setValueAtTime(volume * 0.5, now);
          gain.gain.exponentialRampToValueAtTime(0.0001, now + 0.08);

          osc.connect(gain);
          gain.connect(ctx.destination);

          osc.start(now);
          osc.stop(now + 0.08);
          break;
        }

        case 'rain':
        case 'ambience': {
          const bufferSize = ctx.sampleRate * Math.min(duration, 4);
          const noiseBuffer = ctx.createBuffer(1, bufferSize, ctx.sampleRate);
          const output = noiseBuffer.getChannelData(0);
          for (let i = 0; i < bufferSize; i++) {
            output[i] = Math.random() * 2 - 1;
          }
          const whiteNoise = ctx.createBufferSource();
          whiteNoise.buffer = noiseBuffer;

          const filter = ctx.createBiquadFilter();
          filter.type = type === 'rain' ? 'lowpass' : 'bandpass';
          filter.frequency.setValueAtTime(type === 'rain' ? 1400 : 450, now);

          const gain = ctx.createGain();
          gain.gain.setValueAtTime(0.01, now);
          gain.gain.linearRampToValueAtTime(volume * 0.4, now + 0.4);
          gain.gain.linearRampToValueAtTime(0.001, now + duration);

          whiteNoise.connect(filter);
          filter.connect(gain);
          gain.connect(ctx.destination);

          whiteNoise.start(now);
          whiteNoise.stop(now + duration);
          break;
        }

        case 'footstep': {
          const osc = ctx.createOscillator();
          const gain = ctx.createGain();
          osc.type = 'triangle';
          osc.frequency.setValueAtTime(180, now);
          osc.frequency.exponentialRampToValueAtTime(45, now + 0.15);

          gain.gain.setValueAtTime(volume * 0.8, now);
          gain.gain.exponentialRampToValueAtTime(0.001, now + 0.15);

          osc.connect(gain);
          gain.connect(ctx.destination);

          osc.start(now);
          osc.stop(now + 0.15);
          break;
        }

        default:
          break;
      }
    } catch (e) {
      console.warn('Audio synth playback error:', e);
    }
  }

  /**
   * Generates a synthesized audio blob / data URL for downloading or waveform integration
   */
  public generateAudioDataUrl(
    type: 'whoosh' | 'impact' | 'braam' | 'laser' | 'ui-click' | 'rain' | 'ambience' | 'glitch' | 'footstep' | 'riser',
    duration: number = 2.0
  ): string {
    // Generate synthetic WAV header and samples in memory
    const sampleRate = 22050;
    const numSamples = Math.floor(sampleRate * duration);
    const buffer = new ArrayBuffer(44 + numSamples * 2);
    const view = new DataView(buffer);

    // RIFF chunk descriptor
    writeString(view, 0, 'RIFF');
    view.setUint32(4, 36 + numSamples * 2, true);
    writeString(view, 8, 'WAVE');

    // FMT sub-chunk
    writeString(view, 12, 'fmt ');
    view.setUint32(16, 16, true);
    view.setUint16(20, 1, true); // PCM format
    view.setUint16(22, 1, true); // Mono
    view.setUint32(24, sampleRate, true);
    view.setUint32(28, sampleRate * 2, true);
    view.setUint16(32, 2, true);
    view.setUint16(34, 16, true);

    // DATA sub-chunk
    writeString(view, 36, 'data');
    view.setUint32(40, numSamples * 2, true);

    // Generate waveform data
    for (let i = 0; i < numSamples; i++) {
      const t = i / sampleRate;
      let sample = 0;

      if (type === 'whoosh') {
        const noise = Math.random() * 2 - 1;
        const env = Math.sin((t / duration) * Math.PI);
        sample = noise * env * 0.6;
      } else if (type === 'impact' || type === 'braam') {
        const freq = 110 * Math.exp(-t * 3.5);
        sample = Math.sin(2 * Math.PI * freq * t) * Math.exp(-t * 2.5);
      } else if (type === 'riser') {
        const freq = 120 + 800 * (t / duration);
        sample = (Math.sin(2 * Math.PI * freq * t) + 0.3 * Math.random()) * (t / duration);
      } else if (type === 'ui-click') {
        sample = Math.sin(2 * Math.PI * 900 * t) * Math.exp(-t * 35);
      } else {
        sample = (Math.random() * 2 - 1) * 0.4;
      }

      const intSample = Math.max(-32768, Math.min(32767, sample * 32767));
      view.setInt16(44 + i * 2, intSample, true);
    }

    const blob = new Blob([buffer], { type: 'audio/wav' });
    return URL.createObjectURL(blob);
  }
}

function writeString(view: DataView, offset: number, string: string) {
  for (let i = 0; i < string.length; i++) {
    view.setUint8(offset + i, string.charCodeAt(i));
  }
}

export const SoundSynth = new SoundSynthEngine();
